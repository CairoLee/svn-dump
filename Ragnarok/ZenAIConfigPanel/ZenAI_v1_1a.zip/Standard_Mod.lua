--------------------------------------------------
-- Standard_Mod.lua
--------------------------------------------------
-- This is the standard mod for ZenAI.
-- Nothing special about this, it's simply a mod
-- that does nothing. It can serve as a template
-- for other mods though.
--------------------------------------------------

--------------------------------------------------
-- Mod Globals
--------------------------------------------------

-- Put Global Variables for your mod here

--------------------------------------------------
-- Mod Functions
--------------------------------------------------

--------------------------------------------------
function ModInit() -- called during AI initialization.
--------------------------------------------------
	-- Put any function replacement or any mod initialization code here
end

-- Add any more functions down here.