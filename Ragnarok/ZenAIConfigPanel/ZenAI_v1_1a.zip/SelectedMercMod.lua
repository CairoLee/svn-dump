-- Please choose your Mercenary mod here
require "./AI/USER_AI/Standard_Mod.lua"
