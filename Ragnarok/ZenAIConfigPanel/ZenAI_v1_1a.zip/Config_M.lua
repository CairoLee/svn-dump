--------------------------------------------------
-- ZenAI 1.1a configuration file (Mercenary)
--------------------------------------------------

-- Options

INVINCIBLE_DELAY      = 3000  -- Milliseconds before the mercenary moves upon AI Init. This is useful when teleporting, because mercenaries are like players--they still get about 3-5 seconds of invulnerability if they do not move or attack after a teleport or portal entry.
CIRCLE_ON_IDLE        = 1     -- 0 = disabled
FOLLOW_AT_ONCE        = 1     -- 0 = disabled. Follow at once the owner if he/she moves away from the enemy
HELP_OWNER_1ST        = true  -- true = when the mercenary is in battle, he/she can switch target to help the owner
KILL_YOUR_ENEMIES_1ST = false -- true = the mercenary kills ALL his/her enemies before to help the owner
HP_PERC_DANGER        = 0     -- HP% below that value makes your mercenary to evade the monsters
HP_PERC_SAFE2ATK      = 50    -- The AI is not aggressive until the mercenary reaches this HP% (> 100 = never agressive)
OWNER_CLOSEDISTANCE   = 2     -- Distance to reach when the mercenary goes to the owner
TOO_FAR_TARGET        = 14    -- Max interception range from the owner
SKILL_TIME_OUT        = 1000  -- The AI doesn't use aggressive skills if more than the specified milliseconds are passed
                              -- from the begin of the attack (unless the skill mode for this monster is "WITH_full_power")
NO_MOVING_TARGETS     = false -- true = the mercenary don't attack monsters that are on movement (ie monsters that are following other players)
ADV_MOTION_CHECK      = false -- true = it tries to detect frozen or trapped monster (for now this works for aggressive monsters only) and area spells


-- Mercenary skills ------------------------------
-- Here you can configure skill levels and the minimum SP amount required in order
-- to activate a skill (the AI will not cast that skill until your merc has
-- more SPs than the specified value). If you set the MinSP to 2000 or higher, you
-- can disable automatic usage of skills on the mercs, since no mercs get that much SP.


-- Bowman Mercenary Skills

AS_ARC_STRF = {} -- Double Strafe
AS_ARC_STRF.MinSP = 12

AS_ARC_REPL = {} -- Arrow Repel
AS_ARC_REPL.MinSP = 15

AS_ARC_FSTR = {} -- Focused Arrow Strike
AS_ARC_FSTR.MinSP = 30

AS_ARC_MGNF = {} -- Magnificat
AS_ARC_MGNF.MinSP = 40


-- Fencer Mercenary Skills

AS_FEN_BASH = {} -- Bash
AS_FEN_BASH.MinSP = 15

AS_FEN_BOWL = {} -- Bowling Bash
AS_FEN_BOWL.MinSP = 22

AS_FEN_PARY = {} -- Parry
AS_FEN_PARY.MinSP = 50

AS_FEN_RFLC = {} -- Shield Reflect
AS_FEN_RFLC.MinSP = 55


-- Spearman Mercenary Skills

AS_LAN_PIRC = {} -- Pierce
AS_LAN_PIRC.MinSP = 7

AS_LAN_BRND = {} -- Brandish Spear
AS_LAN_BRND.MinSP = 12

AS_LAN_GARD = {} -- Guard
AS_LAN_GARD.MinSP = 30

AS_LAN_SPRL = {} -- Clashing Spiral
AS_LAN_SPRL.MinSP = 30

-- Other Mercenary Skills

AS_MER_WQKN = {} -- Weapon Quicken
AS_MER_WQKN.MinSP = 50

AS_MER_CRSH = {} -- Crash
AS_MER_CRSH.MinSP = 10


-- Tactics for all monsters

-- NOTE: The Mercenary defaults to Passive, and automatic attack skill use.
-- To make it Aggressive, replace "BEHA_react" with "BEHA_attack" below.
-- To disable use of attack skills, replace "WITH_slow_power" with "WITH_no_skill" below.
-- More choices can be found in Const.lua.

DEFAULT_BEHA = BEHA_react
DEFAULT_WITH = WITH_slow_power
