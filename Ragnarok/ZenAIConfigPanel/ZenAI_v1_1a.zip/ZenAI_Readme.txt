************************************
ZenAI 1.1a Documentation and Changes
************************************

Features:

 + Supports both the Mercenary and the Homunculus, and enables automatic
   casting of many of their skills.

 + Friends list is done just like in Mir AI, with a twist: The friends
   list is saved onto the hard drive in Friends.txt for the Homunculus,
   and FriendsM.txt for the Mercenary.
   - NOTE: To clear either friends list you can remove the appropriate file
     from the USER_AI folder.

 + The AI is able to automatically cast both buffs and attack skills of
   the Homunculus or Mercenary, depending on the type. Manual skill usage
   is also possible.

 + Modding can be done on either the Homunculus or the Mercenary, or both
   can even use the same or different mods at the same time! This is useful
   if you want to add your own code or replace functions. Additionally,
   many Mir AI mods are backwardly compatible with ZenAI.
   - NOTE: To select a mod, you need to modify SelectedMod.lua to apply a mod
     to the Homunculus, or SelectedMercMod.lua to mod the Mercenary.

 + Automatic player skills of the original Mir AI are taken out to improve
   execution time. (i.e. Automatic Aid Potion, Fire Bolt, Tomahawk Throwing.)
   Remember that these skills no longer work.

 + Many of the same features of Mir AI are included in this AI. This includes:
    - Anti-KS
    - Tact list (Homunculus only)
    - Bug positioning fix code
    - Ability to shoot long range on certain Homuns and Mercs
    - Evades (kites) when HP is below a certain %
    - Circle owner when full (Can be turned off)
    - "Stand By" turns permanent follow mode on or off. Homun/Merc will not
      attack enemies in this mode even if you are being attacked.


Change Log:

 + Version 1.1a
   - Fixed a spelling error causing the Level 9 Fencer to not use Bowling Bash.
 + Version 1.1
   - Config files for Homunculus and Mercenary are seperated.
   - A new config option is added, for Mercenary tele-invulnerability.
   - Some code is better-commented. Extra notes added in documentation.
   - Minor spelling/formatting corrections in some comments.
   - PassiveDB.lua is updated to current iRO standards. (11.3)

 + Version 1.0
   - Initial testing release.


How to Install:

 1. Extract the zip into the AI\USER_AI folder, located under your RO folder.
    + When prompted, overwrite the default files in this folder.

 2. Be sure you have the Homunculus and the Mercenary both customized in your RO client.
    + To toggle customized on a Homunculus you use the /hoai command.
    + To toggle customized on a Mercenary you use the /merai command.

 3. Edit the values in Config.lua to suit your preferences.
    + Comments are available in the configuration file for added information.

 4. Enjoy :)


Credits:

 - ZenAI additions and modifications by Zenia-chan
 - Original Mir AI by Miranda Blade
 - Lots of skills info from Doddler. Nice guide!
