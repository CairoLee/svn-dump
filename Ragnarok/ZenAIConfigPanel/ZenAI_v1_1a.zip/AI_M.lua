--------------------------------------------------
-- ZenAI 1.1a for Mercenaries (derived from Mir AI)
--------------------------------------------------

require "./AI/USER_AI/Const.lua"
require "./AI/USER_AI/Util.lua"
require "./AI/USER_AI/Config_M.lua" -- configuration file
require "./AI/USER_AI/PassiveDB.lua"
require "./AI/USER_AI/Patrol.lua"
require "./AI/USER_AI/SelectedMercMod.lua" -- 3rd party changes

--------------------------------------------------
-- State
--------------------------------------------------
-- from default AI
IDLE_ST              = 0
FOLLOW_ST            = 1
CHASE_ST             = 2
ATTACK_ST            = 3
MOVE_CMD_ST          = 4
STOP_CMD_ST          = 5
ATTACK_OBJECT_CMD_ST = 6
ATTACK_AREA_CMD_ST   = 7
PATROL_CMD_ST        = 8
HOLD_CMD_ST          = 9
SKILL_OBJECT_CMD_ST  = 10
SKILL_AREA_CMD_ST    = 11
FOLLOW_CMD_ST        = 12

-- ZenAI addings
EVADE_ST             = 50
BUGPOSI_ST           = 51
EVADE_COMEBACK       = 2

-- ZenAI "Output movements" (they notify the user about some events):
OUTMOVE_NEWFRIEND_ST = 60 -- The choosen player has been added to the friend-list
OUTMOVE_DELFRIEND_ST = 61 -- " has been removed

--------------------------------------------------
-- Global variable (default AI)
--------------------------------------------------
MyState      = IDLE_ST
MyEnemy      = 0
MyDestX      = 0
MyDestY      = 0
MyPatrolX    = 0
MyPatrolY    = 0
ResCmdList   = List.new()
MyID         = 0
MySkill      = 0
MySkillLevel = 0

--------------------------------------------------
-- Global variable (extra)
--------------------------------------------------

-- Init (please look at AI() function, init section)
Initialized = false
OwnerID     = 0
MercType    = 0
LRASID      = 0
StartupTime = 0
isCircling  = false

-- Current status
CircleDir       = 1 -- Current circle-move direction
CircleBlockTime = 0 -- Time when position started to not change (obstacle encountered?)
CircleBlockStep = 0 -- 0 = all ok; 1 = obstacle? Check a second; 2 = obstacle detected
Evade_ComeBackTime = 0
vMercX         = 0 --\_ I'm really moving?
vMercY         = 0 --/
vMercHP        = 0 ---- hit while chasing?
vOwnerX         = 0 --\_ used in follow at once
vOwnerY         = 0 --/
OwnerX          = 0
OwnerY          = 0
MyX             = 0
MyY             = 0
IdleStartTime   = 0
AtkStartTime    = 0
LastLRAtkTime   = 0 -- time of last long ranged attack (see OnCHASE_ST)
LastLRAtkID     = 0
AtkSkillDoneCount = 0
LastLogTime     = 0
OwnerMoveTime   = 0 -- see follow st

----------------------------------------------------------------
-- This is determined by what type of Mercenary.

LONG_RANGE_SHOOTER = false

-- If Bowman, this value is automatically set to true
-- If Fencer or Spearman, this value is set to false

-- In the Homunculus version of ZenAI, this is a config option.
----------------------------------------------------------------


Tact = {}
MerTact = {}
MerTact.Behav     = -1
MerTact.Skill     = -1
MerTact.Level     = 0

-- Blocked movements
AltAngle        = 0
BlockTime       = 0
BlockFound      = 0
BlockCount      = 0
BlockedPathToEnemyID = 0

BugPosiTime     = 0

-- Output movements
OutMoveTime     = 0
OutMoveTarget   = 0

--------------------------------------------------
-- Skills
--------------------------------------------------
CastDelayEnd = 0

DELAY_SLOW_POWER = 1000 -- for slow_power skill mode

-- Bowman-specific Skills --------------

-- Double Strafe ---------------------
AS_ARC_STRF.SkillID = 8207
AS_ARC_STRF.Level   = 0      -- Level is determined by Mercenary Level
AS_ARC_STRF.HowLast = 0
AS_ARC_STRF.Engaged = false
AS_ARC_STRF.Timeout = 0

-- Arrow Repel -----------------------
AS_ARC_REPL.SkillID = 8214
AS_ARC_REPL.Level   = 1
AS_ARC_REPL.HowLast = 1000
AS_ARC_REPL.Engaged = false
AS_ARC_REPL.Timeout = 0

-- Focused Arrow Strike --------------
AS_ARC_FSTR.SkillID = 8215
AS_ARC_FSTR.Level   = 5
AS_ARC_FSTR.HowLast = 1500
AS_ARC_FSTR.Engaged = false
AS_ARC_FSTR.Timeout = 0

-- Magnificat ------------------------
AS_ARC_MGNF.SkillID = 8222
AS_ARC_MGNF.Level   = 1
AS_ARC_MGNF.HowLast = 15000 * (AS_ARC_MGNF.Level + 1)
AS_ARC_MGNF.Engaged = false
AS_ARC_MGNF.Timeout = 0

-- Fencer-specific Skills --------------

-- Bash ------------------------------

AS_FEN_BASH.SkillID = 8201
AS_FEN_BASH.Level   = 0      -- Level is determined by Mercenary Level
AS_FEN_BASH.HowLast = 0
AS_FEN_BASH.Engaged = false
AS_FEN_BASH.Timeout = 0

-- Bowling Bash ----------------------

AS_FEN_BOWL.SkillID = 8203
AS_FEN_BOWL.Level   = 0      -- Level is determined by Mercenary Level
AS_FEN_BOWL.HowLast = 1000
AS_FEN_BOWL.Engaged = false
AS_FEN_BOWL.Timeout = 0

-- Parry -----------------------------

AS_FEN_PARY.SkillID = 8204
AS_FEN_PARY.Level   = 4
AS_FEN_PARY.HowLast = 10000 + (AS_FEN_PARY.Level * 5000)
AS_FEN_PARY.Engaged = false
AS_FEN_PARY.Timeout = 0

-- Shield Reflect --------------------

AS_FEN_RFLC.SkillID = 8205
AS_FEN_RFLC.Level   = 5
AS_FEN_RFLC.HowLast = 300000
AS_FEN_RFLC.Engaged = false
AS_FEN_RFLC.Timeout = 0

-- Spearman-specific Skills ------------

-- Pierce ----------------------------

AS_LAN_PIRC.SkillID = 8216
AS_LAN_PIRC.Level   = 0      -- Level is determined by Mercenary Level
AS_LAN_PIRC.HowLast = 0
AS_LAN_PIRC.Engaged = false
AS_LAN_PIRC.Timeout = 0

-- Brandish Spear --------------------

AS_LAN_BRND.SkillID = 8217
AS_LAN_BRND.Level   = 0      -- Level is determined by Mercenary Level
AS_LAN_BRND.HowLast = 1000
AS_LAN_BRND.Engaged = false
AS_LAN_BRND.Timeout = 0

-- Guard -----------------------------

AS_LAN_GARD.SkillID = 8220
AS_LAN_GARD.Level   = 0      -- Level is determined by Mercenary Level
AS_LAN_GARD.HowLast = 300000
AS_LAN_GARD.Engaged = false
AS_LAN_GARD.Timeout = 0

-- Clashing Spiral -------------------

AS_LAN_SPRL.SkillID = 8218
AS_LAN_SPRL.Level   = 5
AS_LAN_SPRL.HowLast = 2000
AS_LAN_SPRL.Engaged = false
AS_LAN_SPRL.Timeout = 0

-- Mercenary Unspecific Skills ---------

-- Weapon Quicken --------------------

AS_MER_WQKN.SkillID = 8223
AS_MER_WQKN.Level   = 0      -- Level is determined by Mercenary Type and Level
AS_MER_WQKN.HowLast = 0      -- Determined by Skill Level
AS_MER_WQKN.Engaged = false
AS_MER_WQKN.Timeout = 0

-- Crash -----------------------------

AS_MER_CRSH.SkillID = 8225
AS_MER_CRSH.Level   = 0      -- Level is determined by Mercenary Type and Level
AS_MER_CRSH.HowLast = 1000
AS_MER_CRSH.Engaged = false
AS_MER_CRSH.Timeout = 0

--------------------------------------------------
-- ############ COMMAND PROCESS ###########
--------------------------------------------------

--------------------------------------------------
function OnMOVE_CMD(x, y)
--------------------------------------------------
	Log("OnMOVE_CMD")
	isCircling = false
	if (x == MyDestX and y == MyDestY and MOTION_MOVE == GetV(V_MOTION, MyID)) then
		return
	end

	-- are you adding/removing a friend? ----------
	local actors = GetActors()
	for i,v in ipairs(actors) do
		if (v ~= OwnerID and v ~= MyID) then
			if (0 == IsMonster(v)) then
				local PlayerX, PlayerY = GetV(V_POSITION, v)
				if (PlayerX == x) and (math.abs(PlayerY-y) <=1) then
					FriendList_M_Switch(v) -- update friend list
					OutMoveTime = GetTick() -- notify user
					OutMoveTarget = v
					if isNotFriend(v) then
						MyState = OUTMOVE_DELFRIEND_ST
					else
						MyState = OUTMOVE_NEWFRIEND_ST
					end
					MyDestX = x
					MyDestY = y
					MyEnemy = 0
					MySkill = 0
					return
				end
			end
		end
	end

	if (math.abs(x-MyX) + math.abs(y-MyY) > 15) then
		List.pushleft (ResCmdList,{MOVE_CMD,x,y})
		x = math.floor((x+MyX)/2)
		y = math.floor((y+MyY)/2)
	end

	Move(MyID, x, y)

	MyState = MOVE_CMD_ST
	MyDestX = x
	MyDestY = y
	MyEnemy = 0
	MySkill = 0
end

--------------------------------------------------
function OnSTOP_CMD()
--------------------------------------------------
	Log("OnSTOP_CMD")
	isCircling = false
	if (GetV(V_MOTION,MyID) ~= MOTION_STAND) then
		StopHere("Stop request by user")
	end
end

--------------------------------------------------
function OnATTACK_OBJECT_CMD(id)
--------------------------------------------------
	Log("OnATTACK_OBJECT_CMD")
	isCircling = false
	MySkill = 0
	MyEnemy = id
	vOwnerX, vOwnerY = OwnerX, OwnerY
	MyState = CHASE_ST
end

--------------------------------------------------
function OnATTACK_AREA_CMD(x, y)
--------------------------------------------------
	Log("OnATTACK_AREA_CMD")
	isCircling = false
	if (x ~= MyDestX or y ~= MyDestY or MOTION_MOVE ~= GetV(V_MOTION, MyID)) then
		Move(MyID, x, y)
	end
	MyDestX = x
	MyDestY = y
	MyEnemy = 0
	MyState = ATTACK_AREA_CMD_ST
end

--------------------------------------------------
function OnPATROL_CMD(x, y)
--------------------------------------------------
	Log ("OnPATROL_CMD")
	isCircling = false
	MyPatrolX , MyPatrolY = MyX, MyY
	MyDestX = x
	MyDestY = y
	Move(MyID,x,y)
	MyState = PATROL_CMD_ST
end

--------------------------------------------------
function OnHOLD_CMD()
--------------------------------------------------
	Log("OnHOLD_CMD")
	isCircling = false
	MyDestX = 0
	MyDestY = 0
	MyEnemy = 0
	MyState = HOLD_CMD_ST
end

--------------------------------------------------
function OnSKILL_OBJECT_CMD(level, skill, id)
--------------------------------------------------
	Log("OnSKILL_OBJECT_CMD")
	isCircling = false
	MySkillLevel = level
	MySkill = skill
	MyEnemy = id
	vOwnerX, vOwnerY = OwnerX, OwnerY
	MyState = CHASE_ST
end

--------------------------------------------------
function OnSKILL_AREA_CMD(level, skill, x, y)
--------------------------------------------------
	Log("OnSKILL_AREA_CMD")
	isCircling = false
	Move(MyID,x,y)
	MyDestX = x
	MyDestY = y
	MySkillLevel = level
	MySkill = skill
	MyState = SKILL_AREA_CMD_ST
end



--------------------------------------------------
function OnFOLLOW_CMD()
--------------------------------------------------
	isCircling = false
	if (MyState ~= FOLLOW_CMD_ST) then
		local file = io.open("AI/USER_AI/follow_m.lck", "wb")
		if file then file:close() end
		MoveToOwner(MyID)
		MyState = FOLLOW_CMD_ST
		MyDestX, MyDestY = OwnerX, OwnerY
		MyEnemy = 0
		MySkill = 0
		Log("OnFOLLOW_CMD")
	else
		if FileExists("AI/USER_AI/follow_m.lck") then
			os.remove("AI/USER_AI/follow_m.lck")
		end
		MyState = IDLE_ST
		IdleStartTime = GetTick()
		MyEnemy = 0
		MySkill = 0
		Log("FOLLOW_CMD_ST --> IDLE_ST")
	end
end



--------------------------------------------------
function ProcessCommand(msg)
--------------------------------------------------
	if 	(msg[1] == MOVE_CMD) then
		OnMOVE_CMD(msg[2], msg[3])
		Log("MOVE_CMD")
	elseif (msg[1] == STOP_CMD) then
		OnSTOP_CMD()
		Log("STOP_CMD")
	elseif (msg[1] == ATTACK_OBJECT_CMD) then
		OnATTACK_OBJECT_CMD(msg[2])
		Log("ATTACK_OBJECT_CMD")
	elseif (msg[1] == ATTACK_AREA_CMD) then
		OnATTACK_AREA_CMD(msg[2], msg[3])
		Log("ATTACK_AREA_CMD")
	elseif (msg[1] == PATROL_CMD) then
		OnPATROL_CMD(msg[2], msg[3])
		Log("PATROL_CMD")
	elseif (msg[1] == HOLD_CMD) then
		OnHOLD_CMD()
		Log("HOLD_CMD")
	elseif (msg[1] == SKILL_OBJECT_CMD) then
		OnSKILL_OBJECT_CMD(msg[2], msg[3], msg[4])
		Log("SKILL_OBJECT_CMD")
	elseif (msg[1] == SKILL_AREA_CMD) then
		OnSKILL_AREA_CMD(msg[2], msg[3], msg[4], msg[5])
		Log ("SKILL_AREA_CMD")
	elseif (msg[1] == FOLLOW_CMD) then
		OnFOLLOW_CMD()
		Log("FOLLOW_CMD")
	end
end

--------------------------------------------------
-- ############# STATE PROCESS ############
--------------------------------------------------

--------------------------------------------------
function OnIDLE_ST()
--------------------------------------------------
	-- Log("OnIDLE_ST")

	local cmd = List.popleft(ResCmdList)
	if (cmd ~= nil) then
		ProcessCommand(cmd)
		return
	end

	AtkStartTime = 0
	AtkSkillDoneCount = 0
	MerTact.Behav = -1
	MerTact.Skill = -1

	local CurrTime = GetTick()

	if CurrTime - StartupTime < INVINCIBLE_DELAY then
		-- Don't move or attack! The Merc is invincible right now as a result of a teleport or portal entry. Moving or attacking or using a skill invalidates this invulnerability.
		return
	end

	local MercHP = GetV(V_HP, MyID)
	local MercMaxHP = GetV(V_MAXHP, MyID)
	local MercHPPerc = (MercHP / MercMaxHP) * 100
	local MercSP = GetV(V_SP, MyID)
	local MercMaxSP = GetV(V_MAXSP, MyID)
	OwnerMotion = GetV(V_MOTION, OwnerID)

	if (LONG_RANGE_SHOOTER ~= true) and (CIRCLE_ON_IDLE > 0) and (isCircling == false) then
		if (MercHP == MercMaxHP) and (MercSP == MercMaxSP) then
			if (OwnerMotion == MOTION_STAND or OwnerMotion == MOTION_SIT) and isCloseToOwner() then
				isCircling = true
			end
		end
	end

	-- Is there a new target? -> chase_st
	if CurrTime - StartupTime > 600 then
		local NextTarget = GetMyNextTarget(MercHPPerc)
		if NextTarget ~=0 then
			isCircling = false
			MyEnemy = NextTarget
			local Ex, Ey = GetV(V_POSITION, MyEnemy)
			local AtkRange = GetV(V_ATTACKRANGE, MyID)
			if (math.abs(Ex - MyX) <= AtkRange) and (math.abs(Ey - MyY) <= AtkRange) then
				MyState = ATTACK_ST
				Attack(MyID, MyEnemy)
				AtkStartTime = 0
				Log(string.format("[IDLE_ST -> ATTACK_ST] Target(%d) already near, switch directly to combat", MyEnemy))
			else
				MyState = CHASE_ST
				Log(string.format("[IDLE_ST -> CHASE_ST] Intercepting new target(%d)", MyEnemy))
			end
			vOwnerX, vOwnerY = OwnerX, OwnerY
			return
		else
			if MyState == EVADE_ST then
				isCircling = false
				return
			end
		end
	end

   -- Patrol when HP and SP are full
	if (OwnerMotion ~= MOTION_STAND) and (OwnerMotion ~= MOTION_SIT) then
		isCircling = false
	end
	if isCircling then
		CircleAroundTarget(OwnerID)
	else
		-- Switch to follow if Owner is on movement or far
		if (not isCloseToOwner()) or (owner_dst == -1) then
			FollowOwner("[IDLE_ST -> FOLLOW_ST] owner is far from me")
			return
		end
	end

end

--------------------------------------------------
function OnFOLLOW_ST()
--------------------------------------------------
	-- Log("OnFOLLOW_ST")

	OwnerMotion = GetV(V_MOTION, OwnerID)
	local CurrTime = GetTick()
	if (OwnerMotion ~= MOTION_STAND) and (OwnerMotion ~= MOTION_SIT) then
		OwnerMoveTime = CurrTime
	end

	-- Owner reached? -> idle
	if isCloseToOwner() then
		if (OwnerMotion == MOTION_STAND) or (OwnerMotion == MOTION_SIT) then -- don't stop until the owner stops
			StopHere("[FOLLOW_ST -> IDLE_ST] Owner reached")
		elseif (OwnerMotion == MOTION_ATTACK) or (OwnerMotion == MOTION_ATTACK2) then
			object = GetV(V_TARGET, OwnerID)
			if (object ~= 0) then
				MerTact = GetFullTact(GetV(V_MERTYPE, object))
				if (MerTact.Behav ~= BEHA_avoid) then
					MyState = CHASE_ST
					MyEnemy = object
					AtkStartTime = 0
					AtkSkillDoneCount = 0
					vOwnerX, vOwnerY = OwnerX, OwnerY
					Log("[FOLLOW_ST -> CHASE_ST] Cooperative attack")
				end
			end
		else
			--local angle = math.rad(math.mod(GetTick()/8, 360))
			MyDestX = OwnerX + 1 --math.cos(angle)
			MyDestY = OwnerY --+ math.sin(angle)
			Move(MyID, MyDestX, MyDestY)
		end
		return
	end

	-- Am I bloked?
	if (math.abs(vMercX - MyX) == 0)
	and(math.abs(vMercY - MyY) == 0) then  -- if there is no movement
		if (BlockFound == 0) then
			BlockTime = GetTick() + 300		 -- time-out
			BlockFound = 1
		elseif (BlockFound == 1 and GetTick () > BlockTime) then
			if (OwnerMotion == MOTION_STAND) or (OwnerMotion == MOTION_SIT) then
				local MercHP = GetV(V_HP, MyID)
				local MercMaxHP = GetV(V_MAXHP, MyID)
				local MercHPPerc = (MercHP / MercMaxHP) * 100
				local NextTarget = GetMyNextTarget(MercHPPerc)
				if NextTarget ~= 0 then
					isCircling = false
					MyState = CHASE_ST
					MyEnemy = NextTarget
					vOwnerX, vOwnerY = OwnerX, OwnerY
					Log(string.format("[FOLLOW_ST -> CHASE_ST] Blocked, but target(%d) found", MyEnemy))
					return
				else
					if MyState == EVADE_ST then
						Log("[FOLLOW_ST -> EVADE_ST]")
						return
					end
				end
			end
			BlockFound = 0
			BlockCount = BlockCount + 1
			if BlockCount >= 3 then
				Log("Can't follow in this direction")
				AltAngle = math.rad(math.mod(GetTick(), 360))
				local radius = 12
				MyDestX = MyX + math.cos(AltAngle) * radius
				MyDestY = MyY + math.sin(AltAngle) * radius
				while (radius > 0) and (GetDistance(OwnerX, OwnerY, MyDestX, MyDestY) > TOO_FAR_TARGET) do
					radius = radius - 1
					MyDestX = MyX + math.cos(AltAngle) * radius
					MyDestY = MyY + math.sin(AltAngle) * radius
				end
				if radius > 0 then
					Move(MyID, MyDestX, MyDestY)
					BlockCount = 0
					Log("Can't follow: trying alternate path")
				end
			else
				BlockFound = 0
				MyDestX = OwnerX
				MyDestY = OwnerY
				Move(MyID, OwnerX, OwnerY)
				Log("Can't follow: trying again")
			end
		end
	else
		BlockFound = 0
		BlockCount = 0

		if (CurrTime - OwnerMoveTime > 500) and ((OwnerMotion == MOTION_STAND) or (OwnerMotion == MOTION_SIT)) then
			local MercHP = GetV(V_HP, MyID)
			local MercMaxHP = GetV(V_MAXHP, MyID)
			local MercHPPerc = (MercHP / MercMaxHP) * 100
			local NextTarget = GetMyNextTarget(MercHPPerc)
			if NextTarget ~= 0 then
				isCircling = false
				MyState = CHASE_ST
				MyEnemy = NextTarget
				vOwnerX, vOwnerY = OwnerX, OwnerY
				Log(string.format("[FOLLOW_ST -> CHASE_ST] intercepting target(%d)", MyEnemy))
				return
			else
				if MyState == EVADE_ST then
					Log("[FOLLOW_ST -> EVADE_ST]")
					return
				end
			end
		end

		--local angle = math.rad(math.mod(GetTick()/8, 360))
		MyDestX = OwnerX + 1--math.cos(angle)
		MyDestY = OwnerY --+ math.sin(angle)
		Move(MyID, MyDestX, MyDestY)
	end
	vMercX = MyX
	vMercY = MyY

end

--------------------------------------------------
function OnCHASE_ST()
--------------------------------------------------
	-- Log ("OnCHASE_ST")

	if isToFollowAtOnce() then return end

	-- Target is still OK?
	local isBadTarget = false
	local Ex, Ey = GetV(V_POSITION, MyEnemy)
	if (Ex == -1) then
		Log("Target lost")
		isBadTarget = true
	elseif GetDistance(Ex, Ey, OwnerX, OwnerY) >= TOO_FAR_TARGET then
		Log("Target too far")
		isBadTarget = true
	elseif isKS() or not isMobMotionOK(MyEnemy, nil) then
		Log("Target is KS or has suspect motion")
		isBadTarget = true
	end

	-- Get a new target if it's necessary
	local MercHP = GetV(V_HP, MyID)
	local MercMaxHP = GetV(V_MAXHP, MyID)
	local MercHPPerc = (MercHP / MercMaxHP) * 100
	local NextTarget = GetMyNextTarget(MercHPPerc)
	if not isBadTarget and NextTarget ~= 0 then
		local EnemyDst = GetDistance2(MyEnemy, MyID)
                if (EnemyDst <= 2) or (EnemyDst <= GetDistance2(NextTarget, MyID)) then
                	NextTarget = 0
		end
	end
	if NextTarget ~= 0 then
		MyEnemy = NextTarget
		vOwnerX, vOwnerY = OwnerX, OwnerY
		AtkStartTime = 0
		AtkSkillDoneCount = 0
		Log(string.format("Intercepting new target(%d)", MyEnemy))
	else
		if isBadTarget and MyState ~= EVADE_ST then
			StopHere("[CHASE_ST -> IDLE_ST] no alternative target found")
			return
		end
	end

	-- Mercenary long range attack
	local CurrTime = GetTick()
	if LRASID ~=0 then
		if (AtkStartTime == 0) then
			AtkStartTime = CurrTime
		end
		if CanDoAtkSkillsNow() then
			if DoSkill(LRASID, MyEnemy) then -- ##### AGGRESSIVE SKILL #####
				AtkSkillDoneCount = AtkSkillDoneCount + 1
				LastLRAtkTime = CurrTime
				LastLRAtkID = MyEnemy
			end
		end
	end

	-- Am I in combat position? -> attack_st
	local AtkRange = GetV(V_ATTACKRANGE, MyID)
	if (math.abs(Ex - MyX) <= AtkRange) and (math.abs(Ey - MyY) <= AtkRange) then
		MyState = ATTACK_ST
		if AtkSkillDoneCount == 0 then
			AtkStartTime = 0
		end
		Attack(MyID, MyEnemy)
		Log(string.format("[CHASE_ST -> ATTACK_ST] Target(%d) reached, switch to combat", MyEnemy))
		return
	end

	if LONG_RANGE_SHOOTER == true then
		if isCloseToOwner() then
			Attack(MyID, MyEnemy)
		else
			Log("Pushed away from owner: coming back")
			-- Besides skills that push your Mercenary away, there is a Gravity's bug too: even with an empty AI script,
			-- the Mercenary moves to arches whom hit him/her
			MyDestX = OwnerX + 1
			MyDestY = OwnerY
			Move(MyID, MyDestX, MyDestY)
		end
	else
		-- Am I bloked?
		if (math.abs(vMercX - MyX) == 0)
		and(math.abs(vMercY - MyY) == 0) then -- if there is no movement
			if (BlockFound == 0) then
				BlockTime = CurrTime + 1000 -- time-out
				BlockFound = 1
			elseif BlockFound == 1 then
				if CurrTime > BlockTime then
					BlockedPathToEnemyID = MyEnemy
					FollowOwner("[CHASE_ST -> FOLLOW_ST] Path to target seems blocked, searching for another target")
					return
				elseif CurrTime > BlockTime - 600 then
					Attack(MyID, MyEnemy) -- it could be a bug position
				end
			end
		else
			BlockFound = 0
			BlockCount = 0
		end

		-- Move to target
		vMercX = MyX; vMercY = MyY
		MyDestX = Ex; MyDestY = Ey
		Move(MyID, MyDestX, MyDestY)
	end
end

--------------------------------------------------
function OnATTACK_ST()
--------------------------------------------------
	-- Log("OnATTACK_ST")

	if isToFollowAtOnce() then return
	end

	if MyEnemy == 0 then
		StopHere("[ATTACK_ST -> IDLE_ST] no enemy to attack")
		return
	end

	-- Get current status information
	local MercHP		= GetV(V_HP, MyID)
	local MercMaxHP	= GetV(V_MAXHP, MyID)
	local MercHPPerc = (MercHP / MercMaxHP) * 100
	local EnemyTarget = GetV(V_TARGET, MyEnemy)

   local CurrTime = GetTick()

	-- Survival Instinct
	if ((EnemyTarget == MyID) and (MercHPPerc < HP_PERC_DANGER))
	or (MerTact.Behav == BEHA_avoid)
	then
		MyState = EVADE_ST
		Evade_ComeBackTime = EVADE_COMEBACK
		Log("[ATTACK_ST -> EVADE_ST] HP < HP_PERC_DANGER or beha=avoid")
		return
	end

	-- Make sure no other monsters are attacking the owner
	if HELP_OWNER_1ST == true then
		local NewTarget = 0
		NewTarget = GetEnemyOf(OwnerID)
		if NewTarget == MyEnemy then
			NewTarget = 0
		end
		if (NewTarget ~= 0) and (NewTarget ~= MyEnemy) then -- if a threat has been detected
			MyEnemy = NewTarget -- change target
			AtkSkillDoneCount = 0
			AtkStartTime = GetTick() -- a new attack starts (usually this reset is in ON_IDLE_ST)
			MerTact = GetFullTact(GetV(V_MERTYPE, NewTarget))
			local Ex, Ey = GetV(V_POSITION, MyEnemy)
			if (math.abs(Ex - MyX) > 1) or (math.abs(Ey - MyY) > 1) then
				Log("[ATTACK_ST -> CHASE_ST] Switch target -> my owner enemy")
				MyState = CHASE_ST
				if LONG_RANGE_SHOOTER ~= true then
					MyDestX, MyDestY = GetV(V_POSITION, MyEnemy)
					Move(MyID, MyDestX, MyDestY)
				end
				Attack(MyID, MyEnemy)
			else
				Log("Switch target -> my owner enemy (already in close combat position)")
				DoCombat()
			end
			vOwnerX, vOwnerY = OwnerX, OwnerY
			return
		end
	end

	-- Change target when the enemy is dead or lost
	local Ex, Ey = GetV(V_POSITION, MyEnemy)
	if (Ex == -1) or (MOTION_DEAD == GetV(V_MOTION, MyEnemy)) then
		Log(string.format("MyEnemy(%d) lost or dead. Searching for next target", MyEnemy))
		local NextTarget = GetMyNextTarget(MercHPPerc)
		if NextTarget ~=0 then
			MyEnemy = NextTarget
			AtkSkillDoneCount = 0
			AtkStartTime = GetTick() -- a new attack starts (usually this reset is in ON_IDLE_ST)
		else
			if MyState ~= EVADE_ST then
				StopHere("[ATTACK_ST -> IDLE_ST] No more immediate targets")
			end
			return
		end
	end

	-- Intercept the enemy when he/she moves
	if LONG_RANGE_SHOOTER ~= true then
		if (math.abs(Ex - MyX) > 1) or (math.abs(Ey - MyY) > 1) then
			Log(string.format("[ATTACK_ST -> CHASE_ST] Enemy(%d) moved to (%d, %d), while I was at (%d, %d)", MyEnemy, Ex, Ey, MyX, MyY))
			MyState = CHASE_ST
			MyDestX = Ex; MyDestY = Ey
			Move(MyID, MyDestX, MyDestY)
			Attack(MyID, MyEnemy)
			return
		end
	end

	DoCombat()

	-- bug position check
	if (CurrTime - AtkStartTime > 20000) -- after 20"
	and (GetV(V_MOTION, MyID) == MOTION_STAND) -- this don't seem actually to work [...]
	then
		if BugPosiTime == 0 then
			BugPosiTime = CurrTime
			Log("Bug position check has been started")
		end
		-- Log(string.format("Bug position check: my motion = %d", GetV(V_MOTION, MyID)))
		if CurrTime - BugPosiTime > 1000 then
			MyState = BUGPOSI_ST
			AtkStartTime = GetTick()
			AtkSkillDoneCount = 0
			Log("[ATTACK_ST -> BUGPOSI_ST] I'm doing no attack movement (Move=%d): starting anti bug position motion")
			return
		end
	else
		BugPosiTime = 0
	end

	return
end

--------------------------------------------------
function OnEVADE_ST()
--------------------------------------------------
	Log ("OnEVADE_ST")

	-------- evasion-end conditions ---------------

	-- 1: if the enemy changes target
	local EnemyTarget = GetV(V_TARGET, MyEnemy)
	if (EnemyTarget ~= MyID) then
		StopHere("[EVADE_ST -> IDLE] Enemy no longer aims at me")
		return
	end

	-- 2: if the enemy is out of sight
	if (true == IsOutOfSight(MyID, MyEnemy)) then
		StopHere("[EVADE_ST -> IDLE] Enemy out of sight")
		return
	end

	-- 3: if the enemy is dead
	if (MOTION_DEAD == GetV(V_MOTION, MyEnemy)) then
		StopHere("[EVADE_ST -> IDLE] Enemy dead")
		return
	end

	-- 4: if HP are OK now
	local MercHP = GetV(V_HP, MyID)
	local MercMaxHP = GetV(V_MAXHP, MyID)
	local MercHPPerc = (MercHP / MercMaxHP) * 100
	if (MercHPPerc > HP_PERC_DANGER) then
		if (MerTact.Behav ~= BEHA_avoid) and (MerTact.Behav ~= BEHA_coward) then
			MyState = ATTACK_ST
			AtkStartTime = 0
			AtkSkillDoneCount = 0
			vOwnerX, vOwnerY = OwnerX, OwnerY
		 	Log("[EVADE_ST -> ATTACK] HPs are ok now")
		  	return
		end
	end

	------- Evading skills ------------------------
	local MercSP = GetV(V_SP, MyID)

	------- Evading maneuvres ---------------------
	CircleAroundTarget(OwnerID)
	return
end

--------------------------------------------------
function OnBUGPOSI_ST()
--------------------------------------------------
	local MercHP		= GetV(V_HP, MyID)
	local MercMaxHP	= GetV(V_MAXHP, MyID)
	local MercHPPerc = (MercHP / MercMaxHP) * 100
   local CurrTime = GetTick()

	local CurrTime = GetTick()
	MoveToOwner(MyID)
	if (CurrTime - AtkStartTime > 1500) or (GetDistance2(OwnerID, MyID) <= 1) then
		StopHere("[BUGPOSI_ST -> IDLE_ST] Bugposi movement is over")
	end
end

--------------------------------------------------
-- ############ OUTPUT MOVEMENTS ##########
--------------------------------------------------

--------------------------------------------------
function OnOUTMOVE_NEWFRIEND_ST()
--------------------------------------------------
	local CurrTime = GetTick() - OutMoveTime
	if CurrTime > 3000 then
		FollowOwner("[ -> FOLLOW_ST] Output movement done")
		return
	else
		local OutMoveX, OutMoveY = GetV(V_POSITION, OutMoveTarget)
		local angle = math.rad(math.mod(CurrTime/4, 360))
		local X = OutMoveX + math.cos(angle) * 3
		local Y = OutMoveY + math.sin(angle) * 3
		Move(MyID, X, Y)
		MyDestX = X
		MyDestY = Y
	end
end

--------------------------------------------------
function OnOUTMOVE_DELFRIEND_ST()
--------------------------------------------------
	local CurrTime = GetTick() - OutMoveTime
	if CurrTime > 3000 then
		FollowOwner("[ -> FOLLOW_ST] Output movement done")
		return
	else
		local OutMoveX, OutMoveY = GetV(V_POSITION, OutMoveTarget)
		local angle = math.rad(math.mod(CurrTime/4, 360))
		local X = OutMoveX + math.cos(angle) * 3
		local Y = OutMoveY
		Move(MyID, X, Y)
		MyDestX = X
		MyDestY = Y
	end
end

--------------------------------------------------
-- ############# COMMAND STATUS ###########
--------------------------------------------------

--------------------------------------------------
function OnMOVE_CMD_ST()
--------------------------------------------------
	Log("OnMOVE_CMD_ST")

	if (MyX == MyDestX and MyY == MyDestY) then
		StopHere("destination reached")
	else
		Move(MyID, MyDestX, MyDestY)
	end
end

--------------------------------------------------
function OnSTOP_CMD_ST()
--------------------------------------------------
end

--------------------------------------------------
function OnATTACK_OBJECT_CMD_ST()
--------------------------------------------------
end

--------------------------------------------------
function OnATTACK_AREA_CMD_ST()
--------------------------------------------------
	Log ("OnATTACK_AREA_CMD_ST")

	local	object = GetEnemyOf(OwnerID)
	if (object == 0) then
		object = GetMyEnemy_AnyNoKS(MyID)
	end

	if (object ~= 0) then -- MYOWNER_ATTACKED_IN or ATTACKED_IN
		MyState = CHASE_ST
		MyEnemy = object
		vOwnerX, vOwnerY = OwnerX, OwnerY
		return
	end

	if (MyX == MyDestX and MyY == MyDestY) then -- DESTARRIVED_IN
		MyState = IDLE_ST
		IdleStartTime = GetTick()
		MyEnemy = 0
	end

end

--------------------------------------------------
function OnPATROL_CMD_ST()
--------------------------------------------------
	Log("OnPATROL_CMD_ST")

	local	object = GetEnemyOf(OwnerID)
	if (object == 0) then
		object = GetMyEnemy_AnyNoKS(MyID)
	end

	if (object ~= 0) then -- MYOWNER_ATTACKED_IN or ATTACKED_IN
		MyState = CHASE_ST
		MyEnemy = object
		vOwnerX, vOwnerY = OwnerX, OwnerY
		Log("[PATROL_CMD_ST -> CHASE_ST] ATTACKED_IN")
		return
	end

	if (MyX == MyDestX and MyY == MyDestY) then -- DESTARRIVED_IN
		MyDestX = MyPatrolX
		MyDestY = MyPatrolY
		MyPatrolX = x
		MyPatrolY = y
	end
   Move(MyID,MyDestX,MyDestY)

end

--------------------------------------------------
function OnHOLD_CMD_ST ()
--------------------------------------------------
	Log("OnHOLD_CMD_ST")

	if (MyEnemy ~= 0) then
		local d = GetDistance(MyEnemy,MyID)
		if (d ~= -1 and d <= GetV(V_ATTACKRANGE,MyID)) then
			Attack (MyID,MyEnemy)
		else
			MyEnemy = 0
		end
		return
	end

	local	object = GetEnemyOf(OwnerID)
	if (object == 0) then
		object = GetMyEnemy_AnyNoKS(MyID)
		if (object == 0) then
			return
		end
	end

	MyEnemy = object

end

--------------------------------------------------
function OnSKILL_OBJECT_CMD_ST()
--------------------------------------------------
end

--------------------------------------------------
function OnSKILL_AREA_CMD_ST()
--------------------------------------------------
	Log("OnSKILL_AREA_CMD_ST")

	if (GetDistance(MyX, MyY, MyDestX, MyDestY) <= GetV(V_SKILLATTACKRANGE, MyID, MySkill)) then -- DESTARRIVED_IN
		SkillGround (MyID, MySkillLevel, MySkill, MyDestX, MyDestY)
		MyState = IDLE_ST
		IdleStartTime = GetTick()
		MySkill = 0
	end

end

--------------------------------------------------
function OnFOLLOW_CMD_ST ()
--------------------------------------------------
	Log("OnFOLLOW_CMD_ST")

	OwnerMotion = GetV(V_MOTION, OwnerID)
	if not isCloseToOwner()	and (OwnerMotion ~= MOTION_STAND) and (OwnerMotion ~= MOTION_SIT)
	then
		--local angle = math.rad(math.mod(GetTick()/8, 360))
		MyDestX = OwnerX + 1--math.cos(angle)
		MyDestY = OwnerY --+ math.sin(angle)
		Move(MyID, MyDestX, MyDestY)
	end

end

--------------------------------------------------
-- ############# MORE FUNCTIONS ###########
--------------------------------------------------

--------------------------------------------------
function GetMyNextTarget(MercHPPerc)
--------------------------------------------------
	local object = 0

	-- 1: SAFETY FIRSTY! Is the Mercenary is under attack?
	local Agressor = GetMyEnemy_AttackingMe(MyID) -- get TactData too
	local AgBehav, AgSkill, AgLevel
	if Agressor ~= 0 then
		if (MercHPPerc < HP_PERC_DANGER) or (MerTact.Behav == BEHA_avoid) or (MerTact.Behav == BEHA_coward) then
			MyState = EVADE_ST -- flee away if HP < secure level
			MyEnemy = Agressor
			Evade_ComeBackTime = EVADE_COMEBACK
			Log(string.format("[ -> EVADE_ST] GetMyNextTarget() attacked by enemy(%d) (avoid/coward mode or while HP < HP_PERC_DANGER)", MyEnemy))
			return 0
		else -- we are not in danger for now: save these data and let's check for other threats first
         AgBehav = MerTact.Behav
         AgSkill = MerTact.Skill
         AgLevel = MerTact.Level
         if KILL_YOUR_ENEMIES_1ST == true then -- ... unless KILL_YOUR_ENEMIES_1ST is enabled
				Log(string.format("GetMyNextTarget() <defensive scan + KILL_YOUR_ENEMIES_1ST> attacked by enemy(%d)", Agressor))
		      MerTact.Behav = AgBehav
		      MerTact.Skill = AgSkill
		      MerTact.Level = AgLevel
				return Agressor
			end
		end
	end

	-- 2: if the owner or a friend is under attack, help him/her
	object = GetEnemyOf(OwnerID)
	if object ~= 0 then
		if GetV(V_MOTION, object) == MOTION_DEAD then
			object = 0
		end
	end
	if object == 0 then
		for i,v in Friends do
			object = GetEnemyOf(v)
			if GetV(V_MOTION, object) == MOTION_DEAD then
				object = 0
			end
			if object ~= 0 then
				break
			end
		end
	end
	if object ~= 0 then
		Log(string.format("GetMyNextTarget() the owner or a friend is attacked by enemy(%d):", object))
		MerTact = GetFullTact(GetV(V_MERTYPE, object))
		if (MerTact.Behav ~= BEHA_avoid) then
			return object
		end
	end

	-- 3: if the Mercenary is under attack (and his/her life is not in danger, see priority 1)
	if Agressor ~= 0 then
		Log(string.format("GetMyNextTarget() <defensive scan> attacked by enemy(%d)", Agressor))
		MerTact.Behav = AgBehav
		MerTact.Skill = AgSkill
  		MerTact.Level = AgLevel
		return Agressor
	end

	-- 4: if the owner or a friend is attacking --> cooperate
	local OwnerMotion = GetV(V_MOTION, OwnerID)
	local CooTarget = 0
	object = GetV(V_TARGET, OwnerID)
	if (object ~= 0) and (OwnerMotion == MOTION_ATTACK or OwnerMotion == MOTION_ATTACK2) then
	   CooTarget = object
	end
	if CooTarget == 0 then -- Owner is not attacking. Maybe a friend?
		local FriendMotion = 0
		for i,v in Friends do
			object = GetV(V_TARGET, v)
			FriendMotion = GetV(V_MOTION, v)
			if (object ~= 0) and (FriendMotion == MOTION_ATTACK or FriendMotion == MOTION_ATTACK2) then
				CooTarget = object
				break
			end
		end
	end
	if CooTarget ~= 0 then
		Log(string.format("GetMyNextTarget() cooperative target(%d) found:", CooTarget))
		MerTact = GetFullTact(GetV(V_MERTYPE, CooTarget))
		if (MerTact.Behav ~= BEHA_avoid) then
			return CooTarget
		end
	end

	-- 5: aggressive, if HPs are OK and a target is near
	if MercHPPerc > HP_PERC_SAFE2ATK
	then
		object = GetMyEnemy_AnyNoKS(MyID) -- get TactData too
		if (object ~= 0) then
			Log(string.format("GetMyNextTarget() <aggressive scan> target(%d) found", object))
			return object
		end
	end

	return 0
end

--------------------------------------------------
function isToFollowAtOnce()
-- used in OnCHASE_ST() and in OnATTACK_ST()
--------------------------------------------------
	if GetV(V_MOTION, OwnerID) == MOTION_MOVE then
		if FOLLOW_AT_ONCE > 0 then
			local MyEnX, MyEnY = GetV(V_POSITION, MyEnemy)
			local ExtraDst = 0
			if GetDistance(OwnerX, OwnerY, MyX, MyY) < 4 then ExtraDst = 1 end
			if GetDistance(OwnerX, OwnerY, MyEnX, MyEnY) > GetDistance(vOwnerX,vOwnerY, MyEnX, MyEnY) + ExtraDst then
				FollowOwner("[ -> FOLLOW_ST] Owner is moving away")
				return true
			end
		else -- don't follow at once, keep the Mercenary in range
			if GetDistance(OwnerX, OwnerY, MyX, MyY) > TOO_FAR_TARGET - 3 then
				FollowOwner("[ -> FOLLOW_ST] Owner is moving away")
				return true
			end
		end
		vOwnerX = OwnerX; vOwnerY = OwnerY
	end
	return false
end

--------------------------------------------------
function isMobMotionOK(MobID, PlayerList)
-- before to engage in combat with this monster (that seems free because he/she targets nobody and nobody seems to target
-- her/him) check his/her motion. N.B.: the "Get" functions provided by Gravity are very limited, so we can do little for
-- this and the Mercenary in many cases can only try to guess what is happening. I hope Gravity will improve/extend them
--------------------------------------------------
	if 0 == IsMonster(MobID) then return true; end; -- for PvP mods

	local CurrTime = GetTick()
	local mob_motion = GetV(V_MOTION, MobID)
	local mob_type = GetV(V_MERTYPE, MobID)

--MOTION_MOVE: is he/she following another player?
	if mob_motion == MOTION_MOVE then
		if NO_MOVING_TARGETS == true then
			isCircling = false
			Log("---mob is moving")
			return false -- This option is good also to wait until the monsters come close to you
		else
			return true -- [...] (to do: find a way to determine if the moster is following someone in order to make the AI
			-- more kind and friendly) N.B.: tecnically it's not KS to intercept a monster before someone else (the combat
			-- is not yet started and who "mob" just make longer this phase), but it looks quite unfriendly to many players.
		end
--MOTION_STAND: is he/she trapped or frozen?
	elseif mob_motion == MOTION_STAND then
		if ADV_MOTION_CHECK == true then
			-- this is optional, because it's not reliable and gives false positives
			if NoAggroMob[mob_type] == nil then -- is this an immobile or passive monster?
				Log("---mob trapped")
				return false -- mobile/aggro mob = trapped, frozen or obstacled (exceptions: [...] temporary passive mode, archers)
			else
				return true -- immobile/passive mob. [...] (to do: find a way to chek if it's trapped) that's tricky: passive
				-- monsters stands at regular intervals and immobile mobs stands all the time, but even them could get trapped
				-- (e.g. Clocks) or frozen (e.g. Zenorks); also archers are usually immobile. Maybe we could check the distance from
				-- other players, but for example Zenork are looters and so distance has not great meaning.
			end
		else
			return true
		end
-- MOTION_HIT: who hit him/her?
	elseif mob_motion == MOTION_HIT and MyState ~= ATTACK_ST then
		if ADV_MOTION_CHECK == true then
			-- this is optional, because it's not reliable and gives false positives
			if (CurrTime - LastLRAtkTime < 2000) and (LastLRAtkID == MobID) then
				return true -- happened shortly after our long ranged attack at this monster: it's our hit. But [...] it could
				-- happen that someone hits our target in the meantime.
			else
				Log("---mob hit by area atk")
				return false -- it seems an hit from another player, maybe an area attack
			end
		else
			return true
		end
-- MOTION_DEAD
	elseif mob_motion == MOTION_DEAD then
		Log("---mob dead")
		return false
	end

-- MOTION_ATTACK, MOTION_ATTACK2, MOTION_SKILL, MOTION_CAST should require some targetings (unless they are area attacks) and so detected before
-- MOTION_PICKUP and MOTION_SIT shouldn't be in monsters

	return true
end

--------------------------------------------------
function isKS()
-- used in OnCHASE_ST()
--------------------------------------------------
	if 0 == IsMonster(MyEnemy) then return false; end -- for PvP mods

	-- look at monster target
	local mob_target = GetV(V_TARGET, MyEnemy)
	if mob_target > 0 then
		if not IsMonster(mob_target) then
			if (mob_target == MyID) or (mob_target == OwnerID) or (Friends[mob_target] ~= nil) then
				return false
			else
				Log("MyEnemy was already in battle, action aborted (anti-KS)")
				return true
			end
		end
	end

	-- look at (not friend) player targets
	local actors = GetActors()
	for i,v in ipairs(actors) do
		if (v ~= OwnerID) and (v ~= MyID) then
			if 0 == IsMonster(v) then -- if it is a player
				if isNotFriend(v) then -- and not a friend
					if GetV(V_TARGET, v) == MyEnemy then
						Log("Another player is aiming at MyEnemy, action aborted (anti-KS)")
						return true
					end
				end
			end
		end
	end

	return false
end

--------------------------------------------------
function StopHere(s)
--------------------------------------------------
	MyState = IDLE_ST
	MyEnemy = 0
	MySkill = 0
	IdleStartTime = GetTick()
	if LONG_RANGE_SHOOTER ~= true and not (MyDestX == OwnerX + 1 and MyDestY == OwnerY) then
		MyDestX, MyDestY = MyX, MyY
		Move(MyID, MyDestX, MyDestY) -- stop at once
	else
		MyDestX, MyDestY = MyX, MyY
	end
	Log("#STOP#" .. s)
end

--------------------------------------------------
function FollowOwner(s)
--------------------------------------------------
	MyState = FOLLOW_ST
	MyEnemy = 0
	MySkill = 0
	BlockFound = 0
	MyDestX, MyDestY = OwnerX, OwnerY
	MoveToOwner(MyID)
	Log(s)
end

--------------------------------------------------
function DoCombat()
--------------------------------------------------
	if (AtkStartTime == 0) then
		AtkStartTime = GetTick()
	end
	if (MySkill == 0) then
		Attack(MyID, MyEnemy)

		local EnemyType = GetV(V_MERTYPE, MyEnemy)
		if (EnemyType < 1078 or EnemyType > 1085) then -- don't waste SP on plants and mushrooms
			-- Double Strafe Bowman --------------------
			if (MercType == ARCHER01 or MercType == ARCHER05
			or  MercType == ARCHER06 or MercType == ARCHER09) then
			--------------------------------------------
				if CanDoAtkSkillsNow() then -- Double Strafe
					-- AGGRESSIVE SKILL
					if DoSkill(AS_ARC_STRF, MyEnemy) then
						AtkSkillDoneCount = AtkSkillDoneCount + 1
					end
				end

			-- Arrow Repel Bowman ----------------------
			elseif (MercType == ARCHER03) then
			--------------------------------------------
				if CanDoAtkSkillsNow() then -- Arrow Repel
					-- AGGRESSIVE SKILL
					if DoSkill(AS_ARC_REPL, MyEnemy) then
						AtkSkillDoneCount = AtkSkillDoneCount + 1
					end
				end

			-- Focused Arrow Strike Bowman -------------
			elseif (MercType == ARCHER10) then
			--------------------------------------------
				if CanDoAtkSkillsNow() then -- Focused Arrow Strike
					-- AGGRESSIVE SKILL
					if DoSkill(AS_ARC_FSTR, MyEnemy) then
						AtkSkillDoneCount = AtkSkillDoneCount + 1
					end
				end

			-- Bash Fencer -----------------------------
			elseif (MercType == SWORDMAN01 or MercType == SWORDMAN05
			or      MercType == SWORDMAN07) then
			--------------------------------------------
				if CanDoAtkSkillsNow() then -- Bash
					-- AGGRESSIVE SKILL
					if DoSkill(AS_FEN_BASH, MyEnemy) then
						AtkSkillDoneCount = AtkSkillDoneCount + 1
					end
				end

			-- Bowling Bash Fencer ---------------------
			elseif (MercType == SWORDMAN08 or MercType == SWORDMAN09
			or      MercType == SWORDMAN10) then
			--------------------------------------------
				if CanDoAtkSkillsNow() then -- Bowling Bash
					-- AGGRESSIVE SKILL
					if DoSkill(AS_FEN_BOWL, MyEnemy) then
						AtkSkillDoneCount = AtkSkillDoneCount + 1
					end
				end

			-- Pierce Spearman -------------------------
			elseif (MercType == LANCER01 or MercType == LANCER03
			or      MercType == LANCER05 or MercType == LANCER08) then
			--------------------------------------------
				if CanDoAtkSkillsNow() then -- Pierce
					-- AGGRESSIVE SKILL
					if DoSkill(AS_LAN_PIRC, MyEnemy) then
						AtkSkillDoneCount = AtkSkillDoneCount + 1
					end
				end

			-- Brandish Spearman -----------------------
			elseif (MercType == LANCER02 or MercType == LANCER06
			or      MercType == LANCER09) then
			--------------------------------------------
				if CanDoAtkSkillsNow() then -- Brandish Spear
					-- AGGRESSIVE SKILL
					if DoSkill(AS_LAN_BRND, MyEnemy) then
						AtkSkillDoneCount = AtkSkillDoneCount + 1
					end
				end

			-- Clashing Spiral Spearman ----------------
			elseif (MercType == LANCER10) then
			--------------------------------------------
				if CanDoAtkSkillsNow() then -- Clashing Spiral
					-- AGGRESSIVE SKILL
					if DoSkill(AS_LAN_SPRL, MyEnemy) then
						AtkSkillDoneCount = AtkSkillDoneCount + 1
					end
				end

			-- Crash Fencer/Spearman -------------------
			elseif (MercType == SWORDMAN04 or MercType == LANCER04) then
			--------------------------------------------
				if CanDoAtkSkillsNow() then -- Crash
					-- AGGRESSIVE SKILL
					if DoSkill(AS_MER_CRSH, MyEnemy) then
						AtkSkillDoneCount = AtkSkillDoneCount + 1
					end
				end
			end

			-- Magnificat Bowman -----------------------
			if (MercType == ARCHER04) then
			--------------------------------------------
				DoSkill(AS_ARC_MGNF, MyID)
			end

			-- Parrying Fencer -------------------------
			if (MercType == SWORDMAN08) then
			--------------------------------------------
				DoSkill(AS_FEN_PARY, MyID)
			end

			-- Shield Reflect Fencer -------------------
			if (MercType == SWORDMAN09) then
			--------------------------------------------
				DoSkill(AS_FEN_RFLC, MyID)
			end

			-- Guard Spearman --------------------------
			if (MercType == LANCER05 or MercType == LANCER09) then
				DoSkill(AS_LAN_GARD, MyID)
			end
			--------------------------------------------

			-- Weapon Quicken --------------------------
			if (MercType == ARCHER03 or MercType == SWORDMAN03
			or  MercType == ARCHER08 or MercType == LANCER06
		        or  MercType == ARCHER10 or MercType == SWORDMAN06
			or  MercType == LANCER10 or MercType == SWORDMAN08
			or  MercType == SWORDMAN10) then
				DoSkill(AS_MER_WQKN, MyID)
			end

		end
	end
	if (MySkill ~= 0) then
		SkillObject(MyID, MySkillLevel, MySkill, MyEnemy)
		MySkill = 0
	end
end

--------------------------------------------------
function CanDoAtkSkillsNow()
-- is it the right time for an aggressive skill?
--------------------------------------------------
	local result = true
	local CurrTime = GetTick()
	local TimeOutElapsed = CurrTime - AtkStartTime > SKILL_TIME_OUT
	if (MerTact.Skill == WITH_no_skill) then
		result = false
	elseif MerTact.Skill == WITH_one_skill then
		-- Log(string.format("AtkSkillDoneCount = %d, CurrTime - AtkStartTime = %d", AtkSkillDoneCount, CurrTime - AtkStartTime))
		if (AtkSkillDoneCount > 1) or  TimeOutElapsed then
			result = false
		end
	elseif MerTact.Skill == WITH_two_skills then
		if (AtkSkillDoneCount > 2) then
			result = false
		end
	elseif MerTact.Skill == WITH_max_skills then
		if TimeOutElapsed then
			result = false
		end
	elseif MerTact.Skill == WITH_slow_power then
		if (LONG_RANGE_SHOOTER ~= true) and (CurrTime - AtkStartTime < DELAY_SLOW_POWER) then
			result = false
		end
	end
	return result
end

--------------------------------------------------
function DoSkill(Skill, Target)
--------------------------------------------------
	if Skill.Level == 0 then return false; end
	local CurrTime = GetTick()
	local MercSP = GetV(V_SP, MyID)
	local result = false
	if Skill.Engaged then -- if the skill is already active (or in delay time), wait until it goes OFF
		if CurrTime > Skill.TimeOut then
			Skill.Engaged = false
		end
	else -- if the skill is OFF, activate it
		if MercSP >= Skill.MinSP then -- if there are enough SP left
			MySkill = Skill.SkillID

			if ((MySkill == AS_ARC_STRF.SkillID)
			and (MerTact.Level ~= -1)) then
				MySkillLevel = MerTact.Level
			else
				MySkillLevel = Skill.Level
			end

			Skill.TimeOut = CurrTime + Skill.HowLast
			Skill.Engaged = true
			SkillObject(MyID, MySkillLevel, MySkill, Target)
			Log(string.format("Done skill %d lvl %d on target %d", MySkill, MySkillLevel, Target))
			result = true
			MySkill = 0
		end
	end
	return result
end

--------------------------------------------------
function CircleAroundTarget(TrgID)
--------------------------------------------------
	Log("### CIRCLE START ###")
	-- Log(string.format("Step move=%d, Evade_ComeBackTime=%d, CircleBlockStep=%d", CircleDir, Evade_ComeBackTime, CircleBlockStep))

	local TrgX, TrgY		= GetV(V_POSITION, TrgID)

	--------------- current destination -----------
	if (Evade_ComeBackTime == EVADE_COMEBACK) or (CircleBlockStep == 2) then
		local angle = math.rad(math.mod(GetTick()/8, 360))
		MyDestX = OwnerX + math.cos(angle)
		MyDestY = OwnerY + math.sin(angle)
	else
		MyDestX = TrgX + AAI_CIRC_X[CircleDir] -- direction defined by the circle step
		MyDestY = TrgY + AAI_CIRC_Y[CircleDir]
	end

	--------------- obstacle detection ------------
	if (math.abs(vMercX - MyX) == 0)
	and(math.abs(vMercY - MyY) == 0) then -- if there is no movement
		if (CircleBlockStep == 0) then
			CircleBlockTime = GetTick() + 700 -- time-out
			CircleBlockStep = 1
		elseif (CircleBlockStep == 1) then -- it is in wait mode until the time out expires
			if (GetTick () > CircleBlockTime) then -- if it expires
				CircleBlockStep = 2 -- we assume that an obstacle was found in the current direction
			end
		end
	else
		CircleBlockStep = 0
	end

	--------------- position reached? -------------
	if  (math.abs(MyDestX - MyX) < 1)
	and (math.abs(MyDestY - MyY) < 1) -- yes!
	then									  -- select next direction
		if (MyState == EVADE_ST) then
			if CircleBlockStep == 2 then
				CircleDir = CircleDir + 1
				Evade_ComeBackTime = 0
			else
				if (Evade_ComeBackTime == EVADE_COMEBACK) then
					if (GetDistance2(MyEnemy, OwnerID) <=1) then
						CircleDir = CircleDir + 2 -- the monster shoud reach the owner, so he/she can help
						Evade_ComeBackTime = 0
					end
				else
					CircleDir = CircleDir + 2
					Evade_ComeBackTime = Evade_ComeBackTime + 1
				end
			end
		else
			CircleDir = CircleDir + 1
			Evade_ComeBackTime = 0
		end
		if (CircleDir > AAI_CIRC_MAXSTEP) then
			CircleDir = 1
		end
	end

	----- record curren position and move on ------
	vMercX = MyX
	vMercY = MyY
	Move(MyID, MyDestX, MyDestY)
	Log("=== CIRCLE END ===")
	return
end

--------------------------------------------------
function GetEnemyOf(id) -- this function is not for PvP Mods
--------------------------------------------------
	local result = 0
	local actors = GetActors()
	local enemies = {}
	local index = 1
	local target
	for i,v in ipairs(actors) do
		if (v ~= OwnerID and v ~= myid) then
			if (IsMonster(v) == 1) then
				if GetV(V_MOTION, v) ~= MOTION_DEAD then
					target = GetV(V_TARGET, v)
					if (target == id) then
						enemies[index] = v
						index = index + 1
					end
				end
			end
		end
	end

	local min_dis = 100
	local dis
	for i,v in ipairs(enemies) do
		dis = GetDistance2(MyID, v)
		if (dis < min_dis) then
			result = v
			min_dis = dis
		end
	end

	return result
end

--------------------------------------------------
function CountEnemiesCloseToOwner()
--------------------------------------------------
	local ecount = 0
	local actors = GetActors()
	for i,v in ipairs(actors) do
		if 1 == IsMonster(v) then
			if (GetDistance2(OwnerID, v) <= 1) and (MOTION_DEAD ~= GetV(V_MOTION, v)) then
				ecount = ecount + 1
			end
		end
	end
	return ecount
end

--------------------------------------------------
function GetMyEnemy_AttackingMe(myid)
--------------------------------------------------
	-- Log(string.format("---- DEFENSIVE SCAN STARTED for ID (%d)", myid))
	local result = 0
	local actors = GetActors()
	local enemy_1st = {} -- primary targets
	local index_1st = 1
	local enemy_std = {} -- normal targets
	local index_std = 1
	local enemy_lss = {} -- last targets
	local index_lss = 1
	local enemy_wkk = {} -- weak targets
	local index_wkk = 1
	local mob_type, mob_target, mobBehav

	-- Fill a list of enemies who have me as target
	for i,v in ipairs(actors) do
		if GetV(V_MOTION, v) ~= MOTION_DEAD then
			if (v ~= OwnerID) and (v ~= MyID) then
				mob_target = GetV(V_TARGET, v)
				if mob_target == MyID then
					mob_type = GetV(V_MERTYPE, v) -- get tact data
					mobBehav = GetTact(V_TACTBEHAV, mob_type)
					if    (mobBehav == BEHA_avoid)
					or    (mobBehav == BEHA_coward) then
						result = v
						break -- this monster is too dangerous: evade from him/her at once!
					elseif (mobBehav == BEHA_attack_1st) or (mobBehav == BEHA_react_1st) then
						enemy_1st[index_1st] = v
						index_1st = index_1st + 1
					elseif (mobBehav == BEHA_attack_last) or (mobBehav == BEHA_react_last) then
						enemy_lss[index_lss] = v
						index_lss = index_lss + 1
					elseif mobBehav == BEHA_attack_weak then
						enemy_wkk[index_wkk] = v
						index_wkk = index_wkk + 1
					else
						enemy_std[index_std] = v
						index_std = index_std + 1
					end
   			end
			end
		end
	end

	-- Search for the closest aggressor -----------
	if result == 0 then
		-- Log("No mob to avoid")
   	result = GetClosest(enemy_1st)
   end
	if result == 0 then
		-- Log("No primary target in range")
		result = GetClosest(enemy_std)
	end
	if result == 0 then
		-- Log("No standard target in range")
		result = GetClosest(enemy_lss)
	end
	if result == 0 then
		-- Log("No low priority target in range")
		local nearest_weak = GetClosest(enemy_wkk)
		if (nearest_weak ~= 0) and (MyState == IDLE_ST) then
			local MercHP = GetV(V_HP, MyID)
			local MercMaxHP = GetV(V_MAXHP, MyID)
			local MercHPPerc = (MercHP / MercMaxHP) * 100
			if (MercHPPerc <= HP_PERC_SAFE2ATK) then
				-- No real threats were found, but some weak (= BEHA_attack_weak) enemies are hitting me: usually the
				-- aggressive scan (GetMyEnemy_AnyNoKS function) takes care of them (in the correct priority order), but
				-- now the Mercenary HPs are under the safe level, so he/she is in defensive-only mode: no agressive
				-- scan will be started at this time! So it's ok to attack now this low priority monster
				result = nearest_weak
			end
		end
	end
	if result == 0 then
		-- Log("No (serious) enemy is attacking me")
	else
		Log(string.format("<defensive scan> Target found (ID %d):", result))
		MerTact = GetFullTact(GetV(V_MERTYPE, result))
	end

	-- Log("---- END OF DEFENSIVE SCAN")
	return result
end

--------------------------------------------------
function GetMyEnemy_AnyNoKS(myid)
--------------------------------------------------
	-- Log(string.format("---- AGGRESSIVE SCAN STARTED for ID (%d)", myid))
	local result = 0
	local actors = GetActors ()
	local players = {}
	local player_idx = 1
	local enemy_1st = {} -- primary targets
	local index_1st = 1
	local enemy_std = {} -- normal targets
	local index_std = 1
	local enemy_lss = {} -- last targets
	local index_lss = 1
	local mob_type, mob_target, mobBehav
	local EnemyMaxHP
	local MercMaxHP = GetV(V_MAXHP, MyID)

	for i,v in ipairs(actors) do -- fill the (not "friend") player list
		if (v ~= OwnerID and v ~= MyID) then
			if (0 == IsMonster(v)) then
				if isNotFriend(v) then
					players[player_idx] = v
					player_idx = player_idx + 1
				end
			end
		end
	end

	for i,v in ipairs(actors) do
		if (v ~= OwnerID) and (v ~= MyID) then 	  -- owner and Mercenary aren't valid target, of course
			if (IsMonster(v) == 1) and (BlockedPathToEnemyID ~= v) then -- if target is a (reachable) monster

				local isOKToAttack = false
				mob_type = GetV(V_MERTYPE, v)		  -- get tact data
				mobBehav = GetTact(V_TACTBEHAV, mob_type)
				if( (mobBehav == BEHA_attack_1st)
				or  (mobBehav == BEHA_attack)
				or  (mobBehav == BEHA_attack_last)
				or  (mobBehav == BEHA_attack_weak)
				) then										  -- OK, this a type of monster to attack
					if isMobMotionOK(v, players) then
						mob_target = GetV(V_TARGET, v)  -- check for the monster's target
						if (mob_target == 0) then	-- if the monster is not in battle
							isOKToAttack = true	-- he/she can be attacked, unless...
							for i2,v2 in ipairs(players) do
								if (v == GetV(V_TARGET, v2)) then
									isOKToAttack = false   -- ...another player is already aiming at him/her (anti-KS)
									break
								end
							end
						else									  -- else, if the monster is already in battle
							if (mob_target == MyID)
							or (mob_target == OwnerID)
							or (not isNotFriend(mob_target))
							or IsMonster(mob_target) then
								isOKToAttack = true		  -- but with me/my owner/a friend, it's OK (anti-KS)
							end
						end
					end
				end

				if isOKToAttack then
					if (mobBehav == BEHA_attack_1st) then
						enemy_1st[index_1st] = v
						index_1st = index_1st + 1
						-- Log(string.format(" added to (1st) as enemyID %d", v))
					elseif (mobBehav == BEHA_attack) then
						enemy_std[index_std] = v
						index_std = index_std + 1
						-- Log(string.format(" added to (std) as enemyID %d", v))
					else -- BEHA_attack_last, BEHA_attack_weak
						enemy_lss[index_lss] = v
						index_lss = index_lss + 1
						-- Log(string.format(" added to (lss) as enemyID %d", v))
					end
				end

			end
		end
	end

	-- Searches for nearest target ---------------
	result = GetClosest(enemy_1st)
	if (result == 0) then
		-- Log("No primary target in range")
		result = GetClosest(enemy_std)
	end
	if (result == 0) then
		-- Log("No standard target in range")
		result = GetClosest(enemy_lss)
	end
	if (result == 0) then
		-- Log("No target in range")
	else
		Log(string.format("<aggressive scan> Target found (ID %d):", result))
		MerTact = GetFullTact(GetV(V_MERTYPE, result))
	end

	BlockedPathToEnemyID = 0
	-- Log("---- END OF AGGRESSIVE SCAN")
	return result
end

--------------------------------------------------
function GetClosest(EnemiesOnSight)
--------------------------------------------------
	local result = 0
	local nearest_dst = 100
	local owner_dst = 0
	local dst = 0
	for i,v in ipairs(EnemiesOnSight) do
		dst = GetDistance2(MyID, v)
		-- Log(string.format("distance from EnemyID %d is %d", v, dst))
		owner_dst = GetDistance2(OwnerID, v)
		if (dst < nearest_dst and owner_dst < TOO_FAR_TARGET) then
			result = v
			nearest_dst = dst
			-- Log(string.format("he/she is now the closest (%d)", nearest_dst))
		end
	end
	return result
end

--------------------------------------------------
function isCloseToOwner()
--------------------------------------------------
	-- OWNER_CLOSEDISTANCE is no longer used
	return (math.abs(OwnerX - MyX) <= 1) and (math.abs(OwnerY - MyY) <= 1)
end
--------------------------------------------------
function Log(s)
--------------------------------------------------
	local CurrTime = GetTick()
	local dt= CurrTime - LastLogTime
	if LastLogTime == 0 then dt = 0 end
	LastLogTime = CurrTime
	TraceAI("| " .. dt .. "ms: " .. s)
end

--------------------------------------------------
function limMove(ID, x, y) -- Movement protection filter
--------------------------------------------------
	if x == -1 or y == -1 then return; end -- not valid coordinates
	if GetDistance(OwnerX, OwnerY, x, y) < TOO_FAR_TARGET then
		Log(string.format("...moving... (state %d)", MyState))
		stdMove(ID, x, y)
	else
		Log("[ -> IDLE_ST] Destination was too far: back to owner")
		MyState = IDLE_ST
		MyEnemy = 0
		MySkill = 0
		IdleStartTime = GetTick()
                MoveToOwner(MyID)
	end
end

--------------------------------------------------
function AI(myid)
--------------------------------------------------
	MyID = myid
	local msg = GetMsg (myid) -- command
	local rmsg = GetResMsg (myid) -- reserved command

	-----------------------------------------------
	if not Initialized then -- AI init. section
	-----------------------------------------------
		Log("===INIT START===")
		OwnerID = GetV(V_OWNER, MyID)
		MercType = GetV(V_MERTYPE, MyID)

		if ((MercType >= ARCHER01) and (MercType <= ARCHER10)) then
			LONG_RANGE_SHOOTER = true
		else
			LONG_RANGE_SHOOTER = false
		end

		-- Double Strafe Bowman --------------------
		if (MercType == ARCHER01 or MercType == ARCHER05
		or  MercType == ARCHER06 or MercType == ARCHER09) then
		--------------------------------------------
			if (MercType == ARCHER01) then
				AS_ARC_STRF.Level = 2
			elseif (MercType == ARCHER05) then
				AS_ARC_STRF.Level = 5
			elseif (MercType == ARCHER06) then
				AS_ARC_STRF.Level = 7
			else
				AS_ARC_STRF.Level = 10
			end

			LRASID = AS_ARC_STRF

		-- Arrow Repel Bowman ----------------------
		elseif (MercType == ARCHER03) then
		--------------------------------------------
			LRASID = AS_ARC_REPL

		-- Focused Arrow Strike Bowman -------------
		elseif (MercType == ARCHER10) then
		--------------------------------------------
			LRASID = AS_ARC_FSTR

		-- Bash Fencer -----------------------------
		elseif (MercType == SWORDMAN01 or MercType == SWORDMAN05
		or      MercType == SWORDMAN07) then
		--------------------------------------------
			if (MercType == SWORDMAN01) then
				AS_FEN_BASH.Level = 1
			elseif (MercType == SWORDMAN05) then
				AS_FEN_BASH.Level = 5
			else
				AS_FEN_BASH.Level = 10
			end

		-- Bowling Bash Fencer ---------------------
		elseif (MercType == SWORDMAN08 or MercType == SWORDMAN09
		or      MercType == SWORDMAN10) then
		--------------------------------------------
			if (MercType == SWORDMAN08) then
				AS_FEN_BOWL.Level = 5
			elseif (MercType == SWORDMAN09) then
				AS_FEN_BOWL.Level = 8
			else
				AS_FEN_BOWL.Level = 10
			end

		-- Pierce Spearman -------------------------
		elseif (MercType == LANCER01 or MercType == LANCER03
		or      MercType == LANCER05 or MercType == LANCER08) then
		--------------------------------------------
			if (MercType == LANCER01) then
				AS_LAN_PIRC.Level = 1
			elseif (MercType == LANCER03) then
				AS_LAN_PIRC.Level = 2
			elseif (MercType == LANCER05) then
				AS_LAN_PIRC.Level = 5
			else
				AS_LAN_PIRC.Level = 10
			end

		-- Brandish Spearman -----------------------
		elseif (MercType == LANCER02 or MercType == LANCER06
		or      MercType == LANCER09) then
		--------------------------------------------
			if (MercType == LANCER02) then
				AS_LAN_BRND.Level = 2
			elseif (MercType == LANCER06) then
				AS_LAN_BRND.Level = 5
			else
				AS_LAN_BRND.Level = 10
			end

		-- Crash Fencer/Spearman -------------------
		elseif (MercType == SWORDMAN04 or MercType == LANCER04) then
		--------------------------------------------
			if (MercType == SWORDMAN04) then
				AS_MER_CRSH.Level = 1
			else
				AS_MER_CRSH.Level = 4
			end
		end

		-- Guard Spearman --------------------------
		if (MercType == LANCER05) then
			AS_LAN_GARD.Level = 3
		elseif (MercType == LANCER09) then
			AS_LAN_GARD.Level = 7
		end
		--------------------------------------------

		-- Weapon Quicken --------------------------
		if     (MercType == ARCHER03 or MercType == SWORDMAN03) then
			AS_MER_WQKN.Level = 1
		elseif (MercType == ARCHER08 or MercType == LANCER06) then
			AS_MER_WQKN.Level = 2
		elseif (MercType == ARCHER10 or MercType == SWORDMAN06
		     or MercType == LANCER10) then
			AS_MER_WQKN.Level = 5
		elseif (MercType == SWORDMAN08 or MercType == SWORDMAN10) then
			AS_MER_WQKN.Level = 10
		end

		AS_MER_WQKN.HowLast = 30000 * AS_MER_WQKN.Level
		--------------------------------------------

		FriendList_M_Load()
		stdMove = Move; Move = limMove -- replace Move with the protected version
		StartupTime = GetTick()
		IdleStartTime = StartupTime
		if FileExists("AI/USER_AI/follow_m.lck") then
			MyState = FOLLOW_CMD_ST
		end
		ModInit() -- initialize the mod too
		Log("===INIT DONE===")
		Initialized = true
	end
	-----------------------------------------------

	MyX, MyY = GetV(V_POSITION, MyID)
	OwnerX, OwnerY = GetV(V_POSITION, OwnerID)

	if msg[1] == NONE_CMD then
		if rmsg[1] ~= NONE_CMD then
			if List.size(ResCmdList) < 10 then
				List.pushright (ResCmdList,rmsg)
			end
		end
	else
		List.clear (ResCmdList)
		ProcessCommand (msg)
	end

 	if 	 (MyState == IDLE_ST) then
		OnIDLE_ST()
	elseif (MyState == CHASE_ST) then
		OnCHASE_ST()
	elseif (MyState == EVADE_ST) then
		OnEVADE_ST()
	elseif (MyState == ATTACK_ST) then
		OnATTACK_ST()
	elseif (MyState == FOLLOW_ST) then
		OnFOLLOW_ST()
	elseif (MyState == BUGPOSI_ST) then
		OnBUGPOSI_ST()
	-----------------------------------
	elseif (MyState == OUTMOVE_NEWFRIEND_ST) then
		OnOUTMOVE_NEWFRIEND_ST()
	elseif (MyState == OUTMOVE_DELFRIEND_ST) then
		OnOUTMOVE_DELFRIEND_ST()
	-----------------------------------
	elseif (MyState == MOVE_CMD_ST) then
		OnMOVE_CMD_ST()
	elseif (MyState == STOP_CMD_ST) then
		OnSTOP_CMD_ST()
	elseif (MyState == ATTACK_OBJECT_CMD_ST) then
		OnATTACK_OBJECT_CMD_ST ()
	elseif (MyState == ATTACK_AREA_CMD_ST) then
		OnATTACK_AREA_CMD_ST()
	elseif (MyState == PATROL_CMD_ST) then
		OnPATROL_CMD_ST()
	elseif (MyState == HOLD_CMD_ST) then
		OnHOLD_CMD_ST()
	elseif (MyState == SKILL_OBJECT_CMD_ST) then
		OnSKILL_OBJECT_CMD_ST()
	elseif (MyState == SKILL_AREA_CMD_ST) then
		OnSKILL_AREA_CMD_ST()
	elseif (MyState == FOLLOW_CMD_ST) then
		OnFOLLOW_CMD_ST()
	end

end